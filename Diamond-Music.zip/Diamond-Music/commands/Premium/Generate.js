const { MessageEmbed } = require('discord.js');
const Redeem = require('../../settings/models/Redeem.js');
const moment = require('moment')
var voucher_codes = require('voucher-code-generator')

module.exports = { 
  ownerOnly: true,
    config: {
        name: "generate",
        aliases: ["gencode", "genpremiumcode", "genpremium"],
        usage: "<plan> <amount>",
        description: "Generate a premium code",
        accessableby: "Owner",
    },
    run: async (client, message, args, user, language, prefix) => {
    let codes = [];

    const plan = args[0];
    const plans = ['trial', 'staff', 'premium', 'premium+', 'friend', 'developer '];

    if (!plan) return message.channel.send({ content: `${client.i18n.get(language, "premium", "provide_plan", {
        plans: plans.join(', ')
    })}` })

    if (!plans.includes(args[0]))
      return message.channel.send({ content:  `${client.i18n.get(language, "premium", "plan_invalid", {
        plans: plans.join(', ')
      })}` })

    let time;
    if (plan === 'trial') time = Date.now() + 86400000 * 7;
    if (plan === 'staff') time = Date.now() + 86400000 * 30;
    if (plan === 'premium') time = Date.now() + 86400000 * 365;
    if (plan === 'premium+') time = Date.now() + 86400000 * 730;
    if (plan === 'friend') time = Date.now() + 86400000 * 3650;
    if (plan === 'developer') time = Date.now() + 86400000 * 7300;

    let amount = args[1];
    if (!amount) amount = 1;

    for (var i = 0; i < amount; i++) {
      const codePremium = voucher_codes.generate({
        pattern: '####-####-####-####'
      })

      const code = codePremium.toString().toUpperCase()
      const find = await Redeem.findOne({ code: code })

      if (!find) {
        Redeem.create({
          code: code,
          plan: plan,
          expiresAt: time
        })
        codes.push(`${i + 1} - ${code}`)
      }
    }

    const embed = new MessageEmbed()
      .setColor(client.color)
      .setAuthor(`Generated ${plan} Code`, message.client.user.displayAvatarURL()) //${lang.description.replace("{codes_length}", codes.length).replace("{codes}", codes.join('\n')).replace("{plan}", plan).replace("{expires}", moment(time).format('dddd, MMMM Do YYYY'))}
      .setDescription(`${client.i18n.get(language, "premium", "gen_desc", {
        codes_length: codes.length,
        codes: codes.join('\n'),
        plan: plan,
        expires: moment(time).format('dddd, MMMM Do YYYY')
      })}`)
      .setTimestamp()
      .setFooter({ text: `${client.i18n.get(language, "premium", "gen_footer", {
        prefix: prefix
      })}`, iconURL: message.author.displayAvatarURL() })

      message.channel.send({ embeds: [embed] })
  }
}