const { MessageEmbed, Discord, MessageActionRow, MessageButton } = require('discord.js');

module.exports = {
    config: {
        name: "info",
        description: "Who Creates Diamond Music",
        usage: "info",
        category: "Utilities",
        accessableby: "Members",
        aliases: ["information"]
    },
    run: async (client, message, args, user, language, prefix) => {

        const days = Math.floor(client.uptime / 86400000)
        const hours = Math.floor(client.uptime / 3600000) % 24
        const minutes = Math.floor(client.uptime/ 60000) % 60 //1 Hour = 60 Minutes
        const seconds = Math.floor(client.uptime / 1000) % 60

    const info = new MessageEmbed()
        .setTitle("Diamond Music's Info")
        .setThumbnail(message.client.user.displayAvatarURL())
        .addField(`Changelog:`, `*Version*: \`1.3\`\nOn \`${client.guilds.cache.size}\` Guilds\n[Website](https://diamondmusic.ml/)`)
        .addField(`Uptime:`, `**\`${days} Day(s)\` \`${hours} Hour(s)\` \`${minutes} Min(s)\` \`${seconds}\` Sec(s)**`)
        .addField(`Creator:`, `[benzmeister#5843](https://dev-benzmeister.tk/)`)
        .setColor(client.color)
        .setFooter(`Requested by: ${message.author.username} | Diamond Music`,message.author.displayAvatarURL({ dynamic: true }))

        const row = new MessageActionRow()
        .addComponents(
    
                new MessageButton()
                .setLabel('Invite Me')
                .setEmoji("961977218844729365")
                .setURL("https://discord.com/api/oauth2/authorize?client_id=949301159330455652&permissions=8&scope=bot%20applications.commands")
                .setStyle('LINK'),
                
                new MessageButton()
                .setLabel('Support')
                .setURL("https://discord.gg/ZrNzZYc7Dv")
                .setEmoji("964468647986876426")
                .setStyle('LINK'),
        )

    await message.channel.send({ embeds: [info], components: [row] });
            
    }
};