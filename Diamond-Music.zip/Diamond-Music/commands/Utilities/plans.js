const { MessageEmbed, Discord, MessageActionRow, MessageButton } = require('discord.js');

module.exports = {
    ownerOnly: true,
    config: {
        name: "plans",
        description: "Who Creates Diamond Music",
        usage: "plans",
        category: "Utilities",
        accessableby: "Member",
        aliases: ["plans"]
    },
    run: async (client, message, args, user, language, prefix) => {

    const plans = new MessageEmbed()
        .setTitle("Diamond Music Plans")
        .setThumbnail(message.client.user.displayAvatarURL())
        .setDescription(`Hey ${message.author}, Here are my current working plans.\n
        *› 7 Days Premium Free Trial* ||DM benzmeister#5843||
        \n*› Staff Plan \`[=]\` 1 Month Premium\n( Only Implemented To Zen Developments Staff Team )*
        \n*› Premium Plan \`[=]\` 1 Year Premium*
        \n*› Premium+ Plan \`[=]\` 2 Years Premium*
        \n*› Friend Plan \`[=]\` 10 Years Premium\n( Must Be Friend Of The Owner \`benzmeister\` )*
        \n*› Developer Plan \`[=]\` Lifetime Plan\n( Must Have The Developer Role on Zen Developments Server )*`)
        .setColor(client.color)
        .setFooter(`Need a Plan?\nContact benzmeister#5843`,message.author.displayAvatarURL({ dynamic: true }))

        const row = new MessageActionRow()
        .addComponents(
    
                new MessageButton()
                .setLabel('Buy Here')
                .setEmoji("962241713215242330")
                .setURL("https://discord.gg/ZrNzZYc7Dv")
                .setStyle('LINK'),
        )

    await message.channel.send({ embeds: [plans], components: [row] });
            
    }
};