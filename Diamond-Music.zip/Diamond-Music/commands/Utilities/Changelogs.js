const { MessageEmbed, Discord, MessageActionRow, MessageButton } = require('discord.js');

module.exports = {
    config: {
        name: "changelogs",
        description: "Who Creates Diamond Music",
        usage: "plans",
        category: "Utilities",
        accessableby: "Member",
        aliases: ["logs"]
    },
    run: async (client, message, args, user, language, prefix) => {

    const changelogs = new MessageEmbed()
        .setTitle("My Current Changelogs")
        .setDescription(`Hey there ${message.author}, Here are the changes that happened to me.\n
        *☑ Added New Plans and Rename The Old Ones\nImage Link: [https://i.imgur.com/2xYyOKB.png]*
        \n*☑ Added Buttons on Help Panel\nImage Link: [https://i.imgur.com/kbZa8ns.png]*
        \n*☑ Remodel Play Panel\nImage Link: [https://i.imgur.com/nK3Nw9W.pngs]*
        \n*☑ Added Guild Count on Info Commandn\nImage Link: [https://i.imgur.com/H7V9lcr.png]*
        \n*☑ Added Changelogs Command\nImage Link: [https://i.imgur.com/mocEED4.png]*`)
        .setColor(client.color)
        .setFooter(`Current Changelogs, as of May 9, 2022`, message.author.displayAvatarURL({ dynamic: true }))
        .setTimestamp()

    await message.channel.send({ embeds: [changelogs] });
            
    }
};