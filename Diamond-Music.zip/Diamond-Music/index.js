const MainClient = require("./diamondmusic");
const client = new MainClient();

client.connect()

module.exports = client; 